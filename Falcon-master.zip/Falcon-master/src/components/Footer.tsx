import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail } from 'lucide-react';
import { FaWhatsapp, FaFacebook, FaInstagram, FaTwitter } from 'react-icons/fa';
import { Helmet } from 'react-helmet-async';

interface FooterProps {
  phoneNumber?: string;
  whatsappNumber?: string;
}

const Footer: React.FC<FooterProps> = ({
  phoneNumber = '+91 7991994541',
 phoneNumber1 = '+91 7709319486',
  whatsappNumber = '+917991994541',
}) => {
  const quickLinks = [
    { name: 'Home', path: '/' },
    { name: 'Spices', path: '/spices' },
    { name: 'Dry Fruits', path: '/dry-fruits' },
    { name: 'About Us', path: '/about' },
  ];

  return (
    <footer className="bg-gray-950 text-white pt-14 relative overflow-hidden">
      {/* ✅ SEO Meta Tags */}
      <Helmet>
        <title>Falcon Foods Masala Dry Fruits</title>
        <meta
          name="description"
          content="Falcon Foods provides premium spices and dry fruits. Trusted partner for high-quality ingredients."
        />
        <meta
          name="keywords"
          content="Falcon Foods, Masala, Spices, Dry Fruits, Premium Ingredients, Food Supplier"
        />
      </Helmet>

      {/* 🌅 Background Banner */}
    

      {/* 🧡 Footer Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">

          {/* 🟠 Company Info */}
          <div>
            <img
              src="/banner.png"
              alt="Falcon Foods Banner"
              className="w-[280px] h-auto mb-5 rounded-2xl shadow-lg border border-gray-800"
            />
            <p className="text-gray-400 leading-relaxed">
              Your trusted partner for <span className="text-orange-400 font-semibold">premium spices</span> and <span className="text-yellow-400 font-semibold">dry fruits</span>.
            </p>
            <div className="flex space-x-3 mt-5">
              <a
                href={`tel:${phoneNumber}`}
                className="bg-orange-600 p-2 rounded-full hover:bg-orange-700 transition-all shadow-md"
                aria-label="Call Falcon Foods"
              >
                <Phone size={20} />
              </a>
              <a
                href="mailto:info@falconfoods.com"
                className="bg-green-600 p-2 rounded-full hover:bg-green-700 transition-all shadow-md"
                aria-label="Email Falcon Foods"
              >
                <Mail size={20} />
              </a>
              <a
                href={`https://wa.me/${whatsappNumber}?text=Hello%20Falcon%20Foods%2C%20I'm%20interested%20in%20your%20products.%20Hi!%20I%20came%20from%20your%20website%20https%3A%2F%2Fwww.falconfood.in%2F%20and%20I%20want%20to%20know%20more%20about%20Falcon%20Foods.`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-500 p-2 rounded-full hover:bg-green-600 transition-all shadow-md"
                aria-label="Chat on WhatsApp"
              >
                <FaWhatsapp size={20} />
              </a>
            </div>
          </div>

          {/* 🟡 Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-orange-400 border-b border-orange-600 inline-block pb-1">
              Quick Links
            </h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    className="text-gray-400 hover:text-orange-400 transition-colors duration-200"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* 🟢 Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-orange-400 border-b border-orange-600 inline-block pb-1">
              Contact
            </h4>
            <div className="space-y-3 text-gray-400">
              <p>📞 {phoneNumber}</p>
              <p>📞 {phoneNumber1}</p>
              <p>✉️ info@falconfoods.com</p>
              <a
                href={`https://wa.me/${whatsappNumber}?text=Hello%20Falcon%20Foods%2C%20I'm%20interested%20in%20your%20products.%20Hi!%20I%20came%20from%20your%20website%20https%3A%2F%2Fwww.falconfood.in%2F%20and%20I%20want%20to%20know%20more%20about%20Falcon%20Foods.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 hover:text-green-400 transition-colors"
              >
                <FaWhatsapp className="text-xl text-green-400" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>

          {/* 🔵 Social Media */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-orange-400 border-b border-orange-600 inline-block pb-1">
              Follow Us
            </h4>
            <div className="flex space-x-5 mt-2">
              <a
                href="#"
                className="text-gray-400 hover:text-blue-500 transition-transform transform hover:scale-110"
                aria-label="Facebook"
              >
                <FaFacebook size={25} />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-pink-500 transition-transform transform hover:scale-110"
                aria-label="Instagram"
              >
                <FaInstagram size={25} />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-sky-400 transition-transform transform hover:scale-110"
                aria-label="Twitter"
              >
                <FaTwitter size={25} />
              </a>
            </div>
          </div>
        </div>

        {/* 🔻 Bottom Section */}
        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-500">
          <p>&copy; 2025 Falcon Foods Manufacturing Company. All rights reserved.</p>
          <p className="opacity-70 mt-2 text-center md:text-right">
            Design & Developed by{' '}
            <a href="https://im-abu-bakar.netlify.app/" target="_blank" rel="noopener noreferrer" className="font-bold text-lg bg-gradient-to-r from-blue-500 via-teal-400 to-green-400 bg-clip-text text-transparent animate-gradient-x cursor-pointer" style={{ backgroundSize: '200% auto' }}>
              Abu Bakar
            </a>
          
          </p>
        </div>
      </div>

      {/* ✨ Gradient Animation */}
      <style>{`
              @keyframes gradient-x {
                0% { background-position: 0% center; }
                100% { background-position: 200% center; }
              }
              .animate-gradient-x { animation: gradient-x 3s linear infinite; }
            `}</style>
    </footer>
  );
};

export default Footer;
