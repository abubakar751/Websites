import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Drawer } from 'antd';
import { Menu, X, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaWhatsapp } from 'react-icons/fa';

const Layout = ({ children }: { children: React.ReactNode }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/products', label: 'Products' },
    { path: '/spices', label: 'Spices' },
    { path: '/dry-fruits', label: 'Dry Fruits' },
    { path: '/about', label: 'About Us' },
    { path: '/contact', label: 'Contact' },
  ];

  const phoneNumber = '+91 7991994541';
  const whatsappNumber = '917991994541';

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50">
      {/* ✅ Navbar */}
      <nav className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md shadow-md z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16 md:h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-3">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-xl md:text-2xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent"
              />
              <motion.img
                src="/banner.png"
                alt="Falcon Banner"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="w-44 h-44 md:w-56 md:h-56 object-contain"
              />
            </Link>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`relative font-medium transition-colors ${
                    location.pathname === link.path
                      ? 'text-orange-600'
                      : 'text-gray-700 hover:text-orange-600'
                  }`}
                >
                  {link.label}
                  {location.pathname === link.path && (
                    <motion.div
                      layoutId="navbar-indicator"
                      className="absolute -bottom-1 left-0 right-0 h-0.5 bg-orange-600"
                    />
                  )}
                </Link>
              ))}

              {/* Phone Link */}
              <a
                href={`tel:${phoneNumber}`}
                className="flex items-center space-x-1 text-orange-600 hover:text-orange-700 transition-colors"
              >
                <Phone size={18} />
                <span className="text-sm font-medium">{phoneNumber}</span>
              </a>

              {/* WhatsApp Link */}
              <a
                href={`https://wa.me/${whatsappNumber}?text=Hi! I came from your website https://www.falconfood.in/ and I want to know more about Falcon Foods.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 text-green-600 hover:text-green-700 transition-colors"
              >
                <FaWhatsapp size={18} />
                <span className="text-sm font-medium">WhatsApp</span>
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <Menu size={24} className="text-gray-700" />
            </button>
          </div>
        </div>
      </nav>

      {/* ✅ Drawer (Mobile Menu) */}
      <Drawer
        placement="right"
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        width={280}
        styles={{
          body: { padding: 0 },
          header: { display: 'none' },
        }}
      >
        <div className="flex flex-col h-full bg-gradient-to-br from-orange-50 to-amber-50">
          <div className="flex justify-between items-center p-4 border-b border-orange-200">
            <span className="text-lg font-bold text-orange-600">Menu</span>
            <button
              onClick={() => setSidebarOpen(false)}
              className="p-2 rounded-lg hover:bg-orange-100 transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Links */}
          <div className="flex-1 flex flex-col space-y-1 p-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setSidebarOpen(false)}
                className={`px-4 py-3 rounded-xl font-medium transition-all ${
                  location.pathname === link.path
                    ? 'bg-orange-600 text-white shadow-lg'
                    : 'text-gray-700 hover:bg-orange-100'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Contact Section */}
          <div className="p-4 border-t border-orange-200 space-y-3">
            <a
              href={`tel:${phoneNumber}`}
              className="flex items-center space-x-3 p-3 rounded-xl bg-orange-100 hover:bg-orange-200 transition-colors"
            >
              <Phone size={20} className="text-orange-600" />
              <div>
                <div className="text-xs text-gray-600">Phone</div>
                <div className="text-sm font-medium text-gray-900">{phoneNumber}</div>
              </div>
            </a>

            <a
              href={`https://wa.me/${whatsappNumber}?text=Hi! I came from your website https://www.falconfood.in/ and I want to know more about Falcon Foods.`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-3 p-3 rounded-xl bg-green-100 hover:bg-green-200 transition-colors shadow-md"
            >
              <FaWhatsapp className="text-green-600 text-2xl" />
              <div>
                <div className="text-xs text-gray-600">WhatsApp</div>
                <div className="text-sm font-medium text-gray-900">Chat with us</div>
              </div>
            </a>
          </div>
        </div>
      </Drawer>

      {/* ✅ Page Content */}
      <main className="pt-16 md:pt-20">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
};

export default Layout;
