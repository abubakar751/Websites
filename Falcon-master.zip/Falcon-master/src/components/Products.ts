export interface Product {
  id: string;
  name: string;
  category: 'masala' | 'dryfruits';
  image: string;
  description: string;
  weight: string;
  benefits?: string[];
}

export const products: Product[] = [
  {
    id: 'garam-masala',
    name: 'Garam Masala',
    category: 'masala',
    image: 'https://spiceeats.com/wp-content/uploads/2020/07/Garam-Masala.jpg',
    description: 'A blend of ground spices that brings warmth and depth to any dish.',
    weight: '100g, 250g, 500g',
    benefits: ['Rich in antioxidants', 'Aids digestion', 'Boosts metabolism']
  },
  {
    id: 'turmeric-powder',
    name: 'Turmeric Powder',
    category: 'masala',
    image: 'https://cpimg.tistatic.com/05189646/b/4/Dry-Turmeric.jpg',
    description: 'Pure and vibrant turmeric powder with anti-inflammatory properties.',
    weight: '100g, 250g, 500g',
    benefits: ['Anti-inflammatory', 'Boosts immunity', 'Natural antiseptic']
  },
  {
    id: 'red-chili-powder',
    name: 'Red Chili Powder',
    category: 'masala',
    image: 'https://www.pentastar.in/wp-content/uploads/2024/02/red-chilli-powder-min.jpg',
    description: 'Premium quality red chili powder that adds perfect heat to your dishes.',
    weight: '100g, 250g, 500g',
    benefits: ['Rich in Vitamin C', 'Boosts metabolism', 'Natural pain relief']
  },
  {
    id: 'coriander-powder',
    name: 'Coriander Powder',
    category: 'masala',
    image: 'https://www.naatigrains.com/image/cache/catalog/naatigrains-products/NG251/coriander-powder-vitamins-iron-calcium-naatigrains-1000x1000.jpg',
    description: 'Freshly ground coriander powder with a distinctive citrusy flavor.',
    weight: '100g, 250g, 500g',
    benefits: ['Aids digestion', 'Controls blood sugar', 'Rich in fiber']
  },
  {
    id: 'cumin-powder',
    name: 'Cumin Powder',
    category: 'masala',
    image: 'https://5.imimg.com/data5/SELLER/Default/2024/7/438570590/CK/GS/CV/225644287/cumin-powder-1000x1000.jpg',
    description: 'Aromatic cumin powder that enhances the flavor of your recipes.',
    weight: '100g, 250g, 500g',
    benefits: ['Improves digestion', 'Rich in iron', 'Boosts immunity']
  },
  {
    id: 'black-pepper',
    name: 'Black Pepper Powder',
    category: 'masala',
    image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/UN/CA/AK/93405372/black-pepper-powder-1000x1000.jpeg',
    description: 'The king of spices with a sharp and mildly spicy flavor.',
    weight: '50g, 100g, 250g',
    benefits: ['Enhances nutrient absorption', 'Aids digestion', 'Antioxidant properties']
  },
  {
    id: 'biryani-masala',
    name: 'Biryani Masala',
    category: 'masala',
    image: 'https://vismaifood.com/storage/app/uploads/public/9a3/26d/362/thumb__700_0_0_0_auto.jpg',
    description: 'Special blend for authentic and aromatic biryani.',
    weight: '50g, 100g, 250g',
    benefits: ['Perfect blend of spices', 'Authentic taste', 'Easy to use']
  },
  {
    id: 'chaat-masala',
    name: 'Chaat Masala',
    category: 'masala',
    image: 'https://5.imimg.com/data5/SELLER/Default/2024/8/440706164/ON/HP/HV/143575985/chat-masala-powder-500x500.png',
    description: 'Tangy and spicy blend perfect for snacks and salads.',
    weight: '50g, 100g, 250g',
    benefits: ['Tangy flavor', 'Digestive aid', 'Versatile use']
  },
  {
    id: 'almonds',
    name: 'Premium Almonds',
    category: 'dryfruits',
    image: 'https://hilltree.in/wp-content/uploads/2020/07/almond.jpg',
    description: 'Crunchy and nutritious California almonds packed with vitamins.',
    weight: '250g, 500g, 1kg',
    benefits: ['Rich in Vitamin E', 'Heart healthy', 'Boosts brain power']
  },
  {
    id: 'cashews',
    name: 'Whole Cashews',
    category: 'dryfruits',
    image: 'https://5.imimg.com/data5/SELLER/Default/2021/3/XJ/BU/PP/111751672/sw-whole-cashew-nut-500x500.jpg',
    description: 'Premium quality whole cashews with a buttery taste.',
    weight: '250g, 500g, 1kg',
    benefits: ['Rich in minerals', 'Heart healthy fats', 'Supports bone health']
  },
  {
    id: 'walnuts',
    name: 'Kashmiri Walnuts',
    category: 'dryfruits',
    image: 'https://img.freepik.com/premium-photo/walnut-walnut-kernel_863013-136364.jpg?w=2000',
    description: 'Premium Kashmiri walnuts known for their superior quality.',
    weight: '250g, 500g, 1kg',
    benefits: ['Brain food', 'Omega-3 rich', 'Supports heart health']
  },
  {
    id: 'pistachios',
    name: 'Roasted Pistachios',
    category: 'dryfruits',
    image: 'https://static.wixstatic.com/media/521031_dbd262413678441dbd2b585097617507~mv2.jpg/v1/fill/w_1000,h_523,al_c,q_90,usm_0.66_1.00_0.01/521031_dbd262413678441dbd2b585097617507~mv2.jpg',
    description: 'Lightly roasted pistachios with natural flavor.',
    weight: '250g, 500g, 1kg',
    benefits: ['High in protein', 'Rich in antioxidants', 'Eye health support']
  },
  {
    id: 'raisins',
    name: 'Golden Raisins',
    category: 'dryfruits',
    image: 'https://i.pinimg.com/originals/5e/84/b6/5e84b65653634abbee18ffc669cc4ec6.jpg',
    description: 'Sweet and chewy golden raisins packed with natural energy.',
    weight: '250g, 500g, 1kg',
    benefits: ['Natural energy boost', 'Rich in iron', 'Aids digestion']
  },
  {
    id: 'dates',
    name: 'Medjool Dates',
    category: 'dryfruits',
    image: 'https://i.etsystatic.com/54102561/c/793/793/110/23/il/2ff9d1/6378903214/il_300x300.6378903214_2sz8.jpg',
    description: 'Large and succulent Medjool dates, naturally sweet.',
    weight: '250g, 500g, 1kg',
    benefits: ['Natural sweetener', 'High in fiber', 'Instant energy']
  },
  {
    id: 'dried-figs',
    name: 'Dried Figs (Anjeer)',
    category: 'dryfruits',
    image: 'https://cdn.shopify.com/s/files/1/0270/2981/products/dried-figs-anjee_1024x1024.jpg?v=1540836721s',
    description: 'Premium quality dried figs rich in nutrients.',
    weight: '250g, 500g, 1kg',
    benefits: ['Rich in fiber', 'Bone health', 'Natural laxative']
  },
  {
    id: 'apricots',
    name: 'Dried Apricots',
    category: 'dryfruits',
    image: 'https://healthydriedfruits.com/wp-content/uploads/2022/12/dried-apricots-g1bd598c29_1920.jpg',
    description: 'Sun-dried apricots with a sweet and tangy taste.',
    weight: '250g, 500g, 1kg',
    benefits: ['Rich in Vitamin A', 'Eye health', 'Skin health']
  },
  {
    id: 'mixed-nuts',
    name: 'Premium Mixed Nuts',
    category: 'dryfruits',
    image: 'https://cdn11.bigcommerce.com/s-hy7go5e5ls/images/stencil/1280x1280/products/206/937/1MN_1_Mixed_nuts__73448.1649443172.jpg?c=1?imbypass=on',
    description: 'A perfect blend of almonds, cashews, pistachios, and walnuts.',
    weight: '250g, 500g, 1kg',
    benefits: ['Complete nutrition', 'Energy boost', 'Heart healthy']
  }
];
