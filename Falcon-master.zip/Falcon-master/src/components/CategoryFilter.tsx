import { motion } from 'framer-motion';
import { Flame, Apple } from 'lucide-react';

interface CategoryFilterProps {
  activeCategory: 'all' | 'masala' | 'dryfruits';
  onCategoryChange: (category: 'all' | 'masala' | 'dryfruits') => void;
}

export default function CategoryFilter({ activeCategory, onCategoryChange }: CategoryFilterProps) {
  const categories = [
    { id: 'all' as const, label: 'All Products', icon: null },
    { id: 'masala' as const, label: 'Masalas', icon: Flame },
    { id: 'dryfruits' as const, label: 'Dry Fruits', icon: Apple }
  ];

  return (
    <div className="flex flex-wrap justify-center gap-4 mb-16">
      {categories.map((category) => {
        const isActive = activeCategory === category.id;
        const Icon = category.icon;
        
        return (
          <motion.button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`relative px-8 py-4 rounded-full font-semibold text-lg transition-all ${
              isActive
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-xl'
                : 'bg-white text-gray-700 hover:bg-gray-50 shadow-lg'
            }`}
          >
            <span className="flex items-center gap-2">
              {Icon && <Icon className="w-5 h-5" />}
              {category.label}
            </span>
            {isActive && (
              <motion.div
                layoutId="activeCategory"
                className="absolute inset-0 bg-gradient-to-r from-orange-600 to-amber-600 rounded-full -z-10"
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
          </motion.button>
        );
      })}
    </div>
  );
}
