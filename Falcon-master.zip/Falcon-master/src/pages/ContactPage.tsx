import { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MessageCircle, MapPin, Clock, Send } from 'lucide-react';
import { message } from 'antd';
import { FaWhatsapp } from 'react-icons/fa';

const ContactPage = () => {
  const phoneNumber = '+91 7991994541';
  const phoneNumber1 = '+91 7709319486';
  const whatsappNumber = '+917991994541';
  const email = 'info@falconfoods.com';

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    message.success('Thank you for contacting us! We will get back to you soon.');
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen">
     <section
  className="relative h-96 bg-cover bg-center bg-no-repeat"
  style={{
    backgroundImage:
      "url('https://claimsclinical.com/wp-content/uploads/2023/09/820x500-Contact-us.png')",
  }}
>
  {/* Gradient overlay */}
  <div className="absolute inset-0 bg-gradient-to-r from-orange-700/80 to-amber-600/70 mix-blend-multiply" />

  {/* Optional dark overlay for better contrast */}
  <div className="absolute inset-0 bg-black/30" />

  <div className="relative h-full flex items-center justify-center">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="text-center text-white drop-shadow-lg"
      >
        <h1 className="text-4xl md:text-6xl font-extrabold mb-4">
          Contact Us
        </h1>
        <p className="text-xl md:text-2xl font-medium text-amber-100">
          We're here to help — get in touch with us today!
        </p>
      </motion.div>
    </div>
  </div>
</section>


      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Get In Touch</h2>

              <div className="space-y-6">
                <motion.a
                  href={`tel:${phoneNumber}`}
                  whileHover={{ scale: 1.02 }}
                  className="flex items-start space-x-4 p-6 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl shadow-md hover:shadow-lg transition-all"
                >
                  <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">Phone</h3>
                    <p className="text-gray-600">{phoneNumber}</p>
                     <p className="text-gray-600">{phoneNumber1}</p>
                    <p className="text-sm text-gray-500 mt-1">Mon - Sat, 9:00 AM - 6:00 PM</p>
                  </div>
                </motion.a>
<motion.a
  href={`https://wa.me/${whatsappNumber}?text=Hi! I came from your website https://www.falconfood.in/ and want to know more about Falcon Foods.`}
  target="_blank"
  rel="noopener noreferrer"
  whileHover={{ scale: 1.02 }}
  className="flex items-start space-x-4 p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl shadow-md hover:shadow-lg transition-all"
>
  <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
    <FaWhatsapp className="w-6 h-6 text-white" /> {/* ✅ Official WhatsApp Icon */}
  </div>
  <div>
    <h3 className="text-lg font-semibold text-gray-900 mb-1">WhatsApp</h3>
    <p className="text-gray-600">Chat with us instantly</p>
    <p className="text-sm text-gray-500 mt-1">Quick response guaranteed</p>
  </div>
</motion.a>

                <motion.a
                  href={`mailto:${email}`}
                  whileHover={{ scale: 1.02 }}
                  className="flex items-start space-x-4 p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl shadow-md hover:shadow-lg transition-all"
                >
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">Email</h3>
                    <p className="text-gray-600">{email}</p>
                    <p className="text-sm text-gray-500 mt-1">We'll respond within 24 hours</p>
                  </div>
                </motion.a>

                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className="flex items-start space-x-4 p-6 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl shadow-md"
                >
                  <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">Address</h3>
                    <p className="text-gray-600">
                       Gala No. A/26, Mamta Industrial Estate <br />
                        near Hayat Garden, behind Sai Vitthal Mandir Road,<br />
                         Golani Naka, Vasai East, Waliv, <br />
                         Vasai-Virar, Maharashtra 401208
                    </p>
                  </div>
                </motion.div>

                <motion.div
  whileHover={{ scale: 1.03, boxShadow: "0 8px 24px rgba(255, 140, 0, 0.25)" }}
  transition={{ type: "spring", stiffness: 300, damping: 15 }}
  className="flex items-center space-x-5 p-6 bg-gradient-to-br from-orange-100 via-amber-50 to-yellow-50 rounded-3xl shadow-sm hover:shadow-lg transition-all duration-300 border border-orange-100"
>
  <div className="relative w-14 h-14 bg-gradient-to-tr from-orange-600 to-amber-500 rounded-full flex items-center justify-center shadow-md">
    <Clock className="w-7 h-7 text-white" />
    <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full ring-2 ring-white animate-pulse"></span>
  </div>

  <div>
    <h3 className="text-xl font-bold text-gray-900 mb-1 tracking-tight flex items-center">
      Business Hours
      <span className="ml-2 text-sm font-medium text-green-600 flex items-center">
        <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span>Open
      </span>
    </h3>
    <p className="text-gray-700 font-medium leading-snug">
      Monday – Sunday <br />
      <span className="text-orange-600 font-semibold text-lg">24×7 Service</span>
    </p>
  </div>
</motion.div>

              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-3xl shadow-xl p-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all"
                      placeholder="Your Name"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all"
                      placeholder="info@falconfoods.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all"
                      placeholder="+91 7991994541"
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">
                      Your Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={5}
                      className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all resize-none"
                      placeholder="Tell us about your requirements..."
                    />
                  </div>

                  <motion.button
                    type="submit"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-orange-600 hover:bg-orange-700 text-white px-6 py-4 rounded-xl font-semibold transition-colors shadow-lg flex items-center justify-center space-x-2"
                  >
                    <Send size={20} />
                    <span>Send Message</span>
                  </motion.button>
                </form>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-br from-orange-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-8"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Find Us Here</h2>
            <p className="text-lg text-gray-600">Visit our manufacturing facility and warehouse</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="rounded-3xl overflow-hidden shadow-2xl"
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d120422.5157827309!2d72.774369388988!3d19.40360633259628!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x3be7afbf8260a713%3A0x9b46d6c2b98afcc!2sGala%20No.%20A%2F26%2C%20Mamta%20Industrial%20Estate%2C%20near%20Hayat%20Garden%2C%20behind%20Sai%20Vitthal%20Mandir%20Road%2C%20Golani%20Naka%2C%20Vasai%20East%2C%20Waliv%2C%20Vasai-Virar%2C%20Maharashtra%20401208!3m2!1d19.4036249!2d72.8567711!5e0!3m2!1sen!2sin!4v1760987805420!5m2!1sen!2sin"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Falcon Foods Location"
            />
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
