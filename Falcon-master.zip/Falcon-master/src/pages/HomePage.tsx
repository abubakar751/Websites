import { Carousel } from 'antd';
import { motion } from 'framer-motion';
import { Phone, MessageCircle, Award, Shield, Truck, Package, Star, ChevronRight } from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const phoneNumber = '+91 7991994541';
  const whatsappNumber = '+917991994541';

  const carouselImages = [
    { url: 'https://img.freepik.com/premium-photo/spices-background_1001626-774.jpg', title: 'Premium Spices' },
    { url: 'https://www.anmoldryfruits.com/images/paralax-img.jpg', title: 'Quality Dry Fruits' },
    { url: 'https://tci.cornell.edu/wp-content/uploads/2022/10/shutterstock_1774549607-887x591.jpg', title: 'Pure & Natural' },
  ];

  const materials = [
    {
      title: 'Premium Quality',
      description: 'Sourced from the finest farms across India',
      icon: Award,
      image: 'https://cdn4.slideserve.com/8125540/premium-quality-in-indian-spices-n.jpg',
    },
    {
      title: 'Natural & Pure',
      description: 'No artificial colors or preservatives',
      icon: Shield,
      image: 'https://img.freepik.com/premium-photo/natural-bounty-organic-dry-fruits-delight_356545-833.jpg',
    },
    {
      title: 'Carefully Selected',
      description: 'Handpicked and quality tested',
      icon: Package,
      image: 'https://www.shutterstock.com/image-photo/whole-wheat-atta-multigrains-soyaragimaizechanajowarbajaraoats-260nw-1962334804.jpg',
    },
  ];

  const bestSellers = [
    {
      name: 'Premium Turmeric Powder',
      image: 'https://www.shrisvb.in/images/Organic-Turmeric-Powder.jpg',
      rating: 5,
    },
    {
      name: 'Red Chili',
      image: 'https://img.freepik.com/premium-photo/closeup-chili-powder-generated-by-ai_1057389-71650.jpg',
      rating: 5,
    },
    {
      name: 'Premium Cashew Nuts',
      image: 'https://5.imimg.com/data5/SELLER/Default/2023/9/341143343/NS/MI/YB/183593231/download-500x500.png',
      rating: 5,
    },
    {
      name: 'California Almonds',
      image: 'https://m.media-amazon.com/images/S/aplus-media-library-service-media/57b0b6af-9ce1-47e3-b333-a685b18ccd21.__CR0,0,971,601_PT0_SX970_V1___.jpg',
      rating: 5,
    },
  ];

  const testimonials = [
    {
      name: 'Sweet Boy Aamir ',
      text: 'Best quality spices! The aroma and taste are unmatched. We have been ordering for 5 years.',
      rating: 5,
    },
    {
      name: 'Mehmet ',
      text: 'Excellent dry fruits quality. Fresh and properly packed. Highly recommend!',
      rating: 5,
    },
    {
      name: 'Zayeem Mote',
      text: 'Reliable supplier for our restaurant chain. Consistent quality and timely delivery.',
      rating: 5,
    },
  ];

  const services = [
    { icon: Package, title: 'Bulk Orders', description: 'Special pricing for wholesale' },
    { icon: Award, title: 'Custom Branding', description: 'Private label packaging' },
    { icon: Truck, title: 'Fast Delivery', description: 'Pan-India shipping' },
    { icon: Shield, title: 'Quality Assured', description: 'Certified products' },
  ];

  const buyers = [
    'Premium Restaurants',
    'Hotel Chains',
    'Retail Stores',
    'Export Partners',
  ];

  return (
    <div className="overflow-hidden">
      <section className="relative h-[600px] md:h-[700px]">
        <Carousel autoplay autoplaySpeed={4000} effect="fade">
          {carouselImages.map((item, index) => (
            <div key={index} className="relative h-[600px] md:h-[700px]">
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${item.url})` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30" />
              </div>
              <div className="relative h-full flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="max-w-2xl"
                  >
                    <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
                      Premium Quality
                      <span className="block text-orange-400">{item.title}</span>
                    </h1>
                    <p className="text-lg md:text-xl text-gray-200 mb-8">
                      Sourced from the finest farms. Delivered with care. Experience the authentic taste of India.
                    </p>
                    <div className="flex flex-wrap gap-4">
                      <a
                        href={`tel:${phoneNumber}`}
                        className="flex items-center space-x-2 bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-full font-semibold transition-all shadow-lg hover:shadow-xl"
                      >
                        <Phone size={20} />
                        <span>Call Now</span>
                      </a>
                      <a
  href={`https://wa.me/${whatsappNumber}?text=I came from your website https://www.falconfood.in/ and I want to know about Falcon Foods`}
  target="_blank"
  rel="noopener noreferrer"
  className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full font-semibold transition-all shadow-lg hover:shadow-xl"
>
  <FaWhatsapp className="text-2xl" />
  <span>WhatsApp Order</span>
</a>
                    </div>
                  </motion.div>
                </div>
              </div>
            </div>
          ))}
        </Carousel>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Falcon Foods?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We bring you the finest quality spices and dry fruits with uncompromising standards
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {materials.map((material, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                className="group"
              >
                <div className="relative overflow-hidden rounded-3xl shadow-lg">
                  <div
                    className="h-64 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                    style={{ backgroundImage: `url(${material.image})` }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <material.icon className="w-12 h-12 mb-3 text-orange-400" />
                    <h3 className="text-2xl font-bold mb-2">{material.title}</h3>
                    <p className="text-gray-200">{material.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-gradient-to-br from-orange-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Products
            </h2>
            <p className="text-lg text-gray-600">
              Discover our premium range of spices and dry fruits
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Link to="/spices">
              <motion.div
                whileHover={{ scale: 1.02 }}
                className="relative overflow-hidden rounded-3xl shadow-xl h-80 cursor-pointer"
              >
                <div
                  className="absolute inset-0 bg-cover bg-center"
                  style={{
                    backgroundImage:
                      'url(https://img.freepik.com/premium-photo/small-wooden-bowls-spices-herbs_1061358-153538.jpg)',
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
                  <h3 className="text-3xl font-bold mb-3">Premium Spices</h3>
                  <p className="text-gray-200 mb-4">
                    Turmeric, Coriander, Red Chili, Cumin, Pepper & More
                  </p>
                  <div className="flex items-center text-orange-400">
                    <span className="font-semibold">Explore Collection</span>
                    <ChevronRight className="ml-2" />
                  </div>
                </div>
              </motion.div>
            </Link>

            <Link to="/dry-fruits">
              <motion.div
                whileHover={{ scale: 1.02 }}
                className="relative overflow-hidden rounded-3xl shadow-xl h-80 cursor-pointer"
              >
                <div
                  className="absolute inset-0 bg-cover bg-center"
                  style={{
                    backgroundImage:
                      'url(https://5.imimg.com/data5/EM/RM/MY-11306184/dry-fruits-tray-500x500.jpg)',
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
                  <h3 className="text-3xl font-bold mb-3">Premium Dry Fruits</h3>
                  <p className="text-gray-200 mb-4">
                    Cashews, Almonds, Dates, Figs, Raisins & More
                  </p>
                  <div className="flex items-center text-orange-400">
                    <span className="font-semibold">Explore Collection</span>
                    <ChevronRight className="ml-2" />
                  </div>
                </div>
              </motion.div>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Best Sellers
            </h2>
            <p className="text-lg text-gray-600">
              Most loved products by our customers
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {bestSellers.map((product, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10, boxShadow: '0 20px 40px rgba(0,0,0,0.15)' }}
                className="bg-white rounded-2xl shadow-lg overflow-hidden"
              >
                <div
                  className="h-56 bg-cover bg-center"
                  style={{ backgroundImage: `url(${product.image})` }}
                />
                <div className="p-5">
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{product.name}</h3>
                  <div className="flex items-center space-x-1">
                    {[...Array(product.rating)].map((_, i) => (
                      <Star key={i} size={16} className="fill-orange-400 text-orange-400" />
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-gradient-to-br from-orange-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Services
            </h2>
            <p className="text-lg text-gray-600">
              Comprehensive solutions for all your needs
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 shadow-lg text-center hover:shadow-xl transition-shadow"
              >
                <div className="w-16 h-16 mx-auto mb-4 bg-orange-100 rounded-full flex items-center justify-center">
                  <service.icon className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Buyers
            </h2>
            <p className="text-lg text-gray-600">
              Trusted by leading businesses across India
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {buyers.map((buyer, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8 text-center shadow-md hover:shadow-lg transition-shadow"
              >
                <h3 className="text-lg font-bold text-gray-900">{buyer}</h3>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-gradient-to-br from-orange-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Our Customers Say
            </h2>
            <p className="text-lg text-gray-600">
              Real feedback from satisfied customers
            </p>
          </motion.div>

          <Carousel autoplay autoplaySpeed={5000}>
            {testimonials.map((testimonial, index) => (
              <div key={index}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="max-w-3xl mx-auto bg-white rounded-3xl shadow-xl p-8 md:p-12"
                >
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} size={24} className="fill-orange-400 text-orange-400 mx-1" />
                    ))}
                  </div>
                  <p className="text-xl text-gray-700 text-center mb-6 italic">
                    "{testimonial.text}"
                  </p>
                  <h4 className="text-lg font-bold text-gray-900 text-center">
                    {testimonial.name}
                  </h4>
                </motion.div>
              </div>
            ))}
          </Carousel>
        </div>
      </section>

      
    </div>
  );
};

export default HomePage;
