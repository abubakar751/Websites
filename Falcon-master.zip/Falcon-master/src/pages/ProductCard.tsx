import { motion } from 'framer-motion';
import { ShoppingBag } from 'lucide-react';

import { ReactElement, JSXElementConstructor, ReactNode, ReactPortal, Key } from 'react';
import { Product } from '../components/Products';

interface ProductCardProps {
  product: Product;
  index: number;
}

export default function ProductCard({ product, index }: ProductCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -10, transition: { duration: 0.3 } }}
      className="bg-white rounded-2xl shadow-lg overflow-hidden group cursor-pointer"
    >
      <div className="relative overflow-hidden aspect-square">
        <motion.img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.4 }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-black/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <motion.button
              initial={{ y: 20, opacity: 0 }}
              whileHover={{ scale: 1.05 }}
              className="w-full bg-white text-gray-900 px-6 py-3 rounded-full font-semibold flex items-center justify-center gap-2 group-hover:opacity-100 opacity-0 transition-opacity duration-300"
            >
              <ShoppingBag className="w-5 h-5" />
              Add to Cart
            </motion.button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="mb-2">
          <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
            product.category === 'masala'
              ? 'bg-orange-100 text-orange-700'
              : 'bg-amber-100 text-amber-700'
          }`}>
            {product.category === 'masala' ? 'Masala' : 'Dry Fruits'}
          </span>
        </div>

        <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
          {product.name}
        </h3>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
          <span className="font-medium">Available: {product.weight}</span>
        </div>

        {product.benefits && product.benefits.length > 0 && (
          <div className="border-t pt-3">
            <p className="text-xs font-semibold text-gray-700 mb-2">Key Benefits:</p>
            <div className="flex flex-wrap gap-1">
              {product.benefits.slice(0, 2).map((benefit: string | number | boolean | ReactElement<any, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | null | undefined, idx: Key | null | undefined) => (
                <span
                  key={idx}
                  className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded"
                >
                  {benefit}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
