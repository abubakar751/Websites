import { motion } from 'framer-motion';
import { Star, Phone, MessageCircle } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { FaWhatsapp } from 'react-icons/fa';
import { Link } from 'react-router-dom';


const DryFruitsPage = () => {
  const phoneNumber = '+91 7991994541';
  const whatsappNumber = '+917991994541';

  const dryFruits = [
    {
      name: 'Premium Cashew Nuts',
      description: 'Grade A cashews from Kerala. Whole, broken, and split varieties. Rich in nutrients and perfect for snacking.',
      image: 'https://5.imimg.com/data5/SELLER/Default/2022/12/QH/SN/FT/14708931/w240-whole-cashew-nut-1000x1000.jpg',
      sizes: '100g, 250g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'California Almonds',
      description: 'Premium quality almonds imported from California. Rich in protein and antioxidants. Perfect for health-conscious customers.',
      image: 'https://imagedelivery.net/X9PXW05EjhQlnmx27Gj20g/bd9795e7-a45d-4d3b-30fb-ac1cc9975200/ogimage',
      sizes: '100g, 250g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Dates',
      description: 'Soft, sweet Medjool dates. Natural energy booster. Premium grade from Middle East. Perfect for gifting.',
      image: 'https://i.pinimg.com/originals/77/25/55/772555b3caa2f857f325af7911456523.jpg',
      sizes: '200g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Dried Figs',
      description: 'Turkish dried figs. Rich in fiber and minerals. Soft texture and naturally sweet. Excellent for digestion.',
      image: 'https://cdn.shopify.com/s/files/1/0270/2981/products/dried-figs-anjee_1024x1024.jpg?v=1540836721',
      sizes: '200g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Golden Raisins',
      description: 'Seedless golden raisins. Sweet and plump. Great for baking and direct consumption. Premium quality.',
      image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/GG/FC/XS/153507137/dried-afgani-munakka-1000x1000.jpeg',
      sizes: '200g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Dried Grapes (Kishmish)',
      description: 'Premium quality dried grapes. Natural sweetness without added sugar. Rich in iron and vitamins.',
      image: 'https://5.imimg.com/data5/SELLER/Default/2021/6/FB/XX/GD/112637816/yellow-raisins-500x500.jpg',
      sizes: '200g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Walnuts',
      description: 'Premium quality walnuts. Rich in omega-3 fatty acids. Halves and pieces available. Kashmir origin.',
      image: 'https://i0.wp.com/www.wonderslist.com/wp-content/uploads/2013/07/Walnuts.jpg?ssl=1',
      sizes: '200g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Mixed Dry Fruits',
      description: 'Premium assortment of cashews, almonds, raisins, and more. Perfect for gifting and celebrations.',
      image: 'https://static.vecteezy.com/system/resources/thumbnails/039/622/785/small_2x/ai-generated-healthy-eating-a-variety-of-nuts-and-fruits-generated-by-ai-free-photo.jpg',
      sizes: '250g, 500g, 1kg, Bulk',
      rating: 5,
    },
  ];

  // SEO structured data for dry fruits
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "ProductCollection",
    "name": "Premium Dry Fruits Collection - Falcon Foods",
    "description": "Premium quality dry fruits including cashews, almonds, dates, figs, raisins from Falcon Foods. Best dry fruits shop in Mumbai, Virar, Vasai, Nalasopara, Palghar.",
    "url": "https://www.falconfood.in/dry-fruits",
    "mainEntity": {
      "@type": "ItemList",
      "itemListElement": dryFruits.map((fruit, index) => ({
        "@type": "ListItem",
        "position": index + 1,
        "item": {
          "@type": "Product",
          "name": fruit.name,
          "description": fruit.description,
          "category": "Dry Fruits & Nuts",
          "brand": {
            "@type": "Brand",
            "name": "Falcon Foods"
          },
          "offers": {
            "@type": "Offer",
            "availability": "https://schema.org/InStock",
            "priceCurrency": "INR",
            "category": "Dry Fruits"
          }
        }
      }))
    }
  };

  return (
    <div className="min-h-screen">
      {/* SEO Meta Tags */}
      <Helmet>
        <title>Premium Dry Fruits & Nuts | Falcon Foods - Best Dry Fruits Shop in Mumbai</title>
        <meta 
          name="description" 
          content="Buy premium quality dry fruits, nuts, cashews, almonds, dates, figs from Falcon Foods. Best dry fruits shop in Mumbai, Virar, Vasai, Nalasopara, Palghar. Custom packaging available." 
        />
        <meta 
          name="keywords" 
          content="Buy dry fruits online Falcon Foods, Premium dry fruits Falcon Foods, Best quality dry fruits Falcon Foods, Organic dry fruits Falcon Foods, Wholesale dry fruits supplier Falcon Foods, Healthy dry fruits Falcon Foods, Indian dry fruits Falcon Foods, Natural dry fruits online Falcon Foods, Dry fruits in bulk Falcon Foods, Dry fruits shop near me Falcon Foods, Falcon Foods dry fruits, Falcon Dry Fruits, dry fruits Mumbai, dry fruits Virar, dry fruits Vasai" 
        />
        <meta name="robots" content="index, follow" />
        <meta name="author" content="Falcon Foods" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        
        {/* Canonical URL */}
        <link rel="canonical" href="https://www.falconfood.in/dry-fruits" />
        
        {/* Open Graph Tags */}
        <meta property="og:title" content="Premium Dry Fruits & Nuts | Falcon Foods - Best Dry Fruits Shop in Mumbai" />
        <meta property="og:description" content="Buy premium quality dry fruits, nuts, cashews, almonds, dates, figs from Falcon Foods. Best dry fruits shop in Mumbai, Virar, Vasai, Nalasopara, Palghar." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.falconfood.in/dry-fruits" />
        <meta property="og:image" content="https://img.freepik.com/premium-photo/dry-fruits-bowl-table-blurred-beautiful-nature-background_917118-2623.jpg" />
        <meta property="og:site_name" content="Falcon Foods" />
        
        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Premium Dry Fruits & Nuts | Falcon Foods" />
        <meta name="twitter:description" content="Best quality dry fruits, nuts, cashews, almonds, dates, figs from Falcon Foods. Available in Mumbai, Virar, Vasai, Nalasopara, Palghar." />
        <meta name="twitter:image" content="https://img.freepik.com/premium-photo/dry-fruits-bowl-table-blurred-beautiful-nature-background_917118-2623.jpg" />
        
        {/* Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>

        {/* Local Business Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "Falcon Foods - Dry Fruits Specialists",
            "description": "Premium Dry Fruits, Nuts, and Healthy Snacks",
            "url": "https://www.falconfood.in",
            "telephone": "+917991994541",
            "address": {
              "@type": "PostalAddress",
              "addressLocality": "Mumbai",
              "addressRegion": "Maharashtra",
              "addressCountry": "IN"
            },
            "areaServed": ["Mumbai", "Virar", "Vasai", "Nalasopara", "Palghar", "Thane", "Andheri", "Borivali", "Dadar", "Bandra", "Malad", "Churchgate", "CST", "Ghatkopar"],
            "knowsAbout": ["Dry Fruits", "Nuts", "Cashews", "Almonds", "Dates", "Figs", "Raisins", "Healthy Snacks", "Organic Foods"],
            "openingHours": "Mo-Su 09:00-21:00",
            "priceRange": "₹₹"
          })}
        </script>
      </Helmet>

      {/* Hidden SEO Text for better ranking */}
      <div style={{ display: 'none' }} aria-hidden="true">
        <h1>Falcon Foods - Premium Dry Fruits & Nuts Shop</h1>
        <p>
          Buy dry fruits online Falcon Foods | Premium dry fruits Falcon Foods | 
          Best quality dry fruits Falcon Foods | Organic dry fruits Falcon Foods | 
          Wholesale dry fruits supplier Falcon Foods | Healthy dry fruits Falcon Foods | 
          Indian dry fruits Falcon Foods | Natural dry fruits online Falcon Foods | 
          Dry fruits in bulk Falcon Foods | Dry fruits shop near me Falcon Foods |
          Falcon Foods dry fruits store | Falcon Dry Fruits | Premium nuts and dry fruits |
          Dry fruits delivery Mumbai | Dry fruits shop Virar | Dry fruits store Vasai |
          Best dry fruits in Nalasopara | Quality dry fruits Palghar
        </p>
        <p>
          Looking for the best dry fruits shop near you? Falcon Foods offers premium quality 
          dry fruits including cashews, almonds, dates, figs, raisins, walnuts, and mixed dry fruits. 
          We are your trusted dry fruits supplier in Mumbai, Virar, Vasai, Nalasopara, Palghar, 
          and surrounding areas. Buy dry fruits online with confidence from Falcon Foods - 
          your partner for healthy and nutritious dry fruits.
        </p>
      </div>

      <section
        className="relative h-96 bg-center bg-cover"
        style={{
          backgroundImage:
            "url('https://img.freepik.com/premium-photo/dry-fruits-bowl-table-blurred-beautiful-nature-background_917118-2623.jpg')",
        }}
      >
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative h-full flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center text-amber-100"
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-4 drop-shadow-lg">
                Premium Dry Fruits
              </h1>
              <p className="text-xl md:text-2xl mb-6 drop-shadow">
                Nature's finest treasures for your health
              </p>
              <p className="text-lg max-w-3xl mx-auto drop-shadow-sm">
                Cashews, Almonds, Dates, Figs, Raisins, Dried Grapes - Available in every size
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Dry Fruits Collection
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Premium quality dry fruits packed with nutrition and taste
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {dryFruits.map((fruit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                className="bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow"
                itemScope
                itemType="https://schema.org/Product"
              >
                <div
                  className="h-64 bg-cover bg-center"
                  style={{ backgroundImage: `url(${fruit.image})` }}
                  itemProp="image"
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xl font-bold text-gray-900" itemProp="name">
                      {fruit.name}
                    </h3>
                    <div className="flex items-center space-x-1">
                      {[...Array(fruit.rating)].map((_, i) => (
                        <Star key={i} size={16} className="fill-orange-400 text-orange-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4" itemProp="description">
                    {fruit.description}
                  </p>
                  <div className="mb-4">
                    <span className="text-sm font-semibold text-gray-700">Available Sizes: </span>
                    <span className="text-sm text-gray-600">{fruit.sizes}</span>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href={`tel:${phoneNumber}`}
                      className="flex-1 flex items-center justify-center space-x-1 bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-full text-sm font-semibold transition-colors"
                      aria-label={`Call Falcon Foods for ${fruit.name}`}
                    >
                      <Phone size={16} />
                      <span>Call</span>
                    </a>
                    <a
                      href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(
                        `Hello! I'm interested in ${fruit.name} from Falcon Foods. I came from your website https://www.falconfood.in/ and would like to know more details.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-full text-sm font-semibold transition-all shadow-md hover:shadow-lg"
                      aria-label={`Message on WhatsApp for ${fruit.name}`}
                    >
                      <FaWhatsapp size={18} className="text-white" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-r from-amber-600 to-orange-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Custom Packaging & Gift Boxes Available
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Perfect for corporate gifting and special occasions. Contact us for customized assortments
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <a
                href={`tel:${phoneNumber}`}
                className="flex items-center space-x-2 bg-white text-orange-600 hover:bg-gray-100 px-8 py-3 rounded-full font-semibold transition-colors shadow-lg"
                aria-label="Call Falcon Foods for dry fruits"
              >
                <Phone size={20} />
                <span>Call Now</span>
              </a>
              <Link
                to="/contact"
                className="flex items-center space-x-2 bg-transparent border-2 border-white hover:bg-white/10 text-white px-8 py-3 rounded-full font-semibold transition-colors"
              >
                <span>Get Quote</span>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">100% Natural</h3>
              <p className="text-gray-600">No artificial additives or preservatives</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Hygienically Packed</h3>
              <p className="text-gray-600">Sealed for freshness and quality</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Premium Grade</h3>
              <p className="text-gray-600">Only the finest quality nuts and fruits</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Location Based SEO Section */}
        </div>
  );
};

export default DryFruitsPage;