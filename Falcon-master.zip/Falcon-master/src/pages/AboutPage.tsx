import { motion } from 'framer-motion';
import { Award, Users, Globe, TrendingUp, Heart, Shield } from 'lucide-react';

const AboutPage = () => {
  const values = [
    {
      icon: Award,
      title: 'Quality First',
      description: 'We never compromise on quality. Every product is carefully selected and tested.',
    },
    {
      icon: Heart,
      title: 'Customer Satisfaction',
      description: 'Our customers are at the heart of everything we do.',
    },
    {
      icon: Shield,
      title: 'Trust & Integrity',
      description: 'Building lasting relationships through honest business practices.',
    },
    {
      icon: Globe,
      title: 'Sustainable Sourcing',
      description: 'Working with farmers who follow sustainable farming practices.',
    },
  ];

  const milestones = [
    { year: '2010', title: 'Company Founded', description: 'Started with a vision to provide quality spices' },
    { year: '2015', title: 'Expanded to Dry Fruits', description: 'Added premium dry fruits to our product line' },
    { year: '2018', title: 'Pan-India Distribution', description: 'Established distribution network across India' },
    { year: '2024', title: 'Leading Supplier', description: 'Serving 500+ businesses nationwide' },
  ];

  return (
    <div className="min-h-screen">
      <section
        className="relative h-96 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            "url('https://img.freepik.com/premium-photo/nuts-dried-fruits-dried-apricots-figs-prunes-raisins-cranberries-pecans-walnuts-pistachios-cashews-hazelnuts-almonds-other-food-background-top-view_630207-3161.jpg')",
        }}
      >
        {/* Warm gradient overlay for brand tone */}
        <div className="absolute inset-0 bg-gradient-to-r from-orange-800/70 via-amber-600/60 to-yellow-500/50 mix-blend-multiply" />

        {/* Dark overlay for contrast */}
        <div className="absolute inset-0 bg-black/30" />

        <div className="relative h-full flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="text-center text-white drop-shadow-lg"
            >
              <h1 className="text-4xl md:text-6xl font-extrabold mb-4 text-amber-100">
                About Falcon Foods
              </h1>
              <p className="text-xl md:text-2xl font-medium text-orange-100 max-w-2xl mx-auto">
                Your trusted partner in premium spices and dry fruits
              </p>
            </motion.div>
          </div>
        </div>
      </section>



      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-600 text-lg leading-relaxed">
                <p>
                  Falcon Foods Manufacturing Company was established with a simple yet powerful vision: to bring the
                  authentic flavors of India to every kitchen across the nation.
                </p>
                <p>
                  For over a decade, we have been sourcing the finest quality spices and dry fruits from trusted
                  farmers and suppliers across India and abroad. Our commitment to quality, purity, and customer
                  satisfaction has made us a preferred choice for households, restaurants, and businesses.
                </p>
                <p>
                  We believe in traditional values combined with modern hygiene standards. Every product that leaves
                  our facility undergoes rigorous quality checks to ensure it meets our high standards.
                </p>
                <p>
                  Today, we proudly serve thousands of satisfied customers and continue to grow with the same
                  dedication and passion that started our journey.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-4">
                <div
                  className="h-64 rounded-2xl bg-cover bg-center shadow-lg"
                  style={{
                    backgroundImage:
                      'url(https://img.freepik.com/premium-photo/indian-spices_1037680-9198.jpg)',
                  }}
                />
                <div
                  className="h-64 rounded-2xl bg-cover bg-center shadow-lg mt-8"
                  style={{
                    backgroundImage:
                      'url(https://img.freepik.com/premium-photo/various-nuts-dried-fruits-wooden-bowls_266870-11809.jpg?w=2000)',
                  }}
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-gradient-to-br from-orange-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-lg text-gray-600">The principles that guide everything we do</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                  <value.icon className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Journey</h2>
            <p className="text-lg text-gray-600">Milestones that shaped our growth</p>
          </motion.div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-orange-200 hidden lg:block" />

            {milestones.map((milestone, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`relative mb-12 ${index % 2 === 0 ? 'lg:pr-1/2' : 'lg:pl-1/2 lg:text-right'
                  }`}
              >
                <div className="lg:w-1/2">
                  <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-6 shadow-lg">
                    <div className="text-3xl font-bold text-orange-600 mb-2">{milestone.year}</div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{milestone.title}</h3>
                    <p className="text-gray-600">{milestone.description}</p>
                  </div>
                </div>

                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-orange-600 rounded-full border-4 border-white hidden lg:block" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-gradient-to-r from-orange-600 to-amber-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
            >
              <Users className="w-16 h-16 mx-auto mb-4" />
              <div className="text-4xl font-bold mb-2">500+</div>
              <div className="text-xl">Happy Clients</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              <Award className="w-16 h-16 mx-auto mb-4" />
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-xl">Products</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              <TrendingUp className="w-16 h-16 mx-auto mb-4" />
              <div className="text-4xl font-bold mb-2">14+</div>
              <div className="text-xl">Years Experience</div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Ready to Experience Quality?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Join hundreds of satisfied customers who trust Falcon Foods for their spice and dry fruit needs
            </p>
            <a
              href="/contact"
              className="inline-block bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-colors shadow-lg"
            >
              Contact Us Today
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
