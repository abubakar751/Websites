import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

import ProductCard from './ProductCard';
import CategoryFilter from '../components/CategoryFilter';
import { Product, products } from '../components/Products';

export default function ProductsSection() {
  const [activeCategory, setActiveCategory] = useState<'all' | 'masala' | 'dryfruits'>('all');

  const filteredProducts = activeCategory === 'all'
    ? products
    : products.filter((product: { category: string; }) => product.category === activeCategory);

  return (
   <section
  id="products"
  className="py-24 bg-[url('https://t4.ftcdn.net/jpg/08/56/18/41/360_F_856184148_UXZsqSIwjaOAWeFMUEEyMeJXrkO1ENSR.jpg')] bg-cover bg-center bg-no-repeat bg-fixed"
>
  <div className="bg-white/70 backdrop-blur-sm">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="text-center mb-16"
      >
        <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
          Our Premium
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-amber-600">
            Product Collection
          </span>
        </h2>
        <p className="text-xl text-gray-700 max-w-3xl mx-auto">
          Handpicked selection of the finest masalas and dry fruits to elevate your culinary experience
        </p>
      </motion.div>

      <CategoryFilter
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
      />

      <AnimatePresence mode="wait">
        <motion.div
          key={activeCategory}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
        >
          {filteredProducts.map((product: Product, index: number) => (
            <ProductCard key={product.id} product={product} index={index} />
          ))}
        </motion.div>
      </AnimatePresence>

      {filteredProducts.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-20"
        >
          <p className="text-2xl text-gray-500">No products found in this category</p>
        </motion.div>
      )}
    </div>
  </div>
</section>

  );
}
