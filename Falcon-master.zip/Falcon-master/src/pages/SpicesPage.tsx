import { motion } from 'framer-motion';
import { Star, Phone, MessageCircle } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { FaWhatsapp } from 'react-icons/fa';
import { Link } from 'react-router-dom';


const SpicesPage = () => {
  const phoneNumber = '+91 7991994541';
  const whatsappNumber = '+917991994541';

  const spices = [
    {
      name: 'Turmeric Powder',
      description: 'Pure turmeric powder with high curcumin content. Known for its vibrant color and health benefits. Available in all sizes.',
      image: 'https://hillvitalusa.com/wp-content/uploads/2024/10/Turmeric-compressor.jpg',
      sizes: '50g, 100g, 250g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Coriander Powder',
      description: 'Freshly ground coriander with authentic aroma. Essential for Indian cuisine. Premium quality seeds.',
      image: 'https://5.imimg.com/data5/XU/CX/OU/SELLER-22868263/organic-dhania-powder-coriander-powder-500x500.jpg',
      sizes: '50g, 100g, 250g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Red Chili Powder',
      description: 'Spicy and vibrant red chili powder. Perfect heat level for all dishes. Kashmir and regular varieties available.',
      image: 'https://wallpapers.com/images/hd/red-chili-powder-1000-x-600-wallpaper-k73wu4x1jv63zmbs.jpg',
      sizes: '50g, 100g, 250g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Cumin Seeds',
      description: 'Aromatic cumin seeds for tempering and grinding. Strong flavor and aroma. Sourced from premium farms.',
      image: 'https://5.imimg.com/data5/RW/BO/BR/SELLER-31196452/jeera-powder-500x500.jpg',
      sizes: '50g, 100g, 250g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Black Pepper',
      description: 'Premium black pepper with strong pungency. Whole and powdered forms available. Kerala origin.',
      image: 'https://www.amirasagro.com/wp-content/uploads/black-pepper-powder.jpg',
      sizes: '50g, 100g, 250g, 500g, 1kg, Bulk',
      rating: 5,
    },
    {
      name: 'Cloves',
      description: 'Aromatic whole cloves for flavor and medicinal use. Premium quality with strong aroma.',
      image: 'https://5.imimg.com/data5/SELLER/Default/2023/2/JD/NH/AA/77191831/dry-cloves-500x500.webp',
      sizes: '25g, 50g, 100g, 250g, 500g, Bulk',
      rating: 5,
    },
    {
      name: 'Flour (Wheat & Multi-grain)',
      description: 'Freshly milled flour from premium wheat. Available in whole wheat and multi-grain varieties.',
      image: 'https://www.alankarmillet.com/images/multigrain-flour-products/special-obesity.jpg',
      sizes: '1kg, 5kg, 10kg, 25kg, Bulk',
      rating: 5,
    },
    {
      name: 'Rice',
      description: 'Premium quality rice varieties including Basmati and regular. Long-grain, aromatic, aged rice.',
      image: 'https://cpimg.tistatic.com/08548497/b/4/Basmati-Rice.jpg',
      sizes: '1kg, 5kg, 10kg, 25kg, Bulk',
      rating: 5,
    },
  ];

  // SEO structured data for spices
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "ProductCollection",
    "name": "Premium Spices Collection - Falcon Foods",
    "description": "Premium quality spices, masalas, rice, flour and dry fruits from Falcon Foods. Best spice brand in Mumbai, Virar, Vasai, Nalasopara, Palghar.",
    "url": "https://www.falconfood.in/spices",
    "mainEntity": {
      "@type": "ItemList",
      "itemListElement": spices.map((spice, index) => ({
        "@type": "ListItem",
        "position": index + 1,
        "item": {
          "@type": "Product",
          "name": spice.name,
          "description": spice.description,
          "category": "Spices & Masalas",
          "brand": {
            "@type": "Brand",
            "name": "Falcon Foods"
          },
          "offers": {
            "@type": "Offer",
            "availability": "https://schema.org/InStock",
            "priceCurrency": "INR",
            "category": "Spices"
          }
        }
      }))
    }
  };

  return (
    <div className="min-h-screen">
      {/* SEO Meta Tags */}
      <Helmet>
        <title>Premium Spices & Masalas | Falcon Foods - Best Spice Shop in Mumbai</title>
        <meta 
          name="description" 
          content="Buy premium quality spices, masalas, rice, flour from Falcon Foods. Best spice shop in Mumbai, Virar, Vasai, Nalasopara, Palghar. Custom packaging available." 
        />
        <meta 
          name="keywords" 
          content="Falcon Foods spice shop, Falcon Foods masala shop, premium spices Mumbai, best dry fruits Virar, spices and masalas Vasai, Falcon Foods Nalasopara, Falcon Spices, Falcon Dry Fruits, buy spices online Mumbai, masala company Palghar" 
        />
        <meta name="robots" content="index, follow" />
        <meta name="author" content="Falcon Foods" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        
        {/* Canonical URL */}
        <link rel="canonical" href="https://www.falconfood.in/spices" />
        
        {/* Open Graph Tags */}
        <meta property="og:title" content="Premium Spices & Masalas | Falcon Foods - Best Spice Shop in Mumbai" />
        <meta property="og:description" content="Buy premium quality spices, masalas, rice, flour from Falcon Foods. Best spice shop in Mumbai, Virar, Vasai, Nalasopara, Palghar." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.falconfood.in/spices" />
        <meta property="og:image" content="https://img.freepik.com/premium-photo/colorful-different-spices_752237-13041.jpg?w=2000" />
        <meta property="og:site_name" content="Falcon Foods" />
        
        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Premium Spices & Masalas | Falcon Foods" />
        <meta name="twitter:description" content="Best quality spices, masalas, rice, flour from Falcon Foods. Available in Mumbai, Virar, Vasai, Nalasopara, Palghar." />
        <meta name="twitter:image" content="https://img.freepik.com/premium-photo/colorful-different-spices_752237-13041.jpg?w=2000" />
        
        {/* Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>

        {/* Local Business Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "Falcon Foods",
            "description": "Premium Spices, Masalas and Dry Fruits Shop",
            "url": "https://www.falconfood.in",
            "telephone": "+917991994541",
            "address": {
              "@type": "PostalAddress",
              "addressLocality": "Mumbai",
              "addressRegion": "Maharashtra",
              "addressCountry": "IN"
            },
            "areaServed": ["Mumbai", "Virar", "Vasai", "Nalasopara", "Palghar", "Thane", "Andheri", "Borivali", "Dadar", "Bandra", "Malad", "Churchgate", "CST", "Ghatkopar"],
            "knowsAbout": ["Spices", "Masalas", "Dry Fruits", "Rice", "Flour", "Indian Groceries"],
            "openingHours": "Mo-Su 09:00-21:00",
            "priceRange": "₹"
          })}
        </script>
      </Helmet>

      {/* Hidden SEO Text for better ranking */}
      <div style={{ display: 'none' }} aria-hidden="true">
        <h1>Falcon Foods - Premium Spices & Dry Fruits Shop</h1>
        <p>
          Falcon Foods spice shop | Falcon Foods dry fruit shop | Falcon Foods near me | 
          Falcon Foods in Mumbai | Falcon Foods in Virar | Falcon Foods in Vasai | 
          Falcon Foods in Nalasopara | Falcon Foods in Palghar | Falcon Foods masala shop | 
          Falcon Foods dry fruits store | Falcon Foods spices and dry fruits | 
          Falcon Dry Fruits by Falcon Foods | Falcon Spices by Falcon Foods | 
          Premium masala company - Falcon Foods | Top dry fruits company - Falcon Foods | 
          Buy dry fruits online Falcon Foods | Best spice brand in Mumbai - Falcon Foods | 
          Falcon Foods Mumbai Suburban | Falcon Foods near Andheri, Borivali, Dadar, Bandra, Malad | 
          Falcon Foods shop near Churchgate, CST, Ghatkopar, Thane | Masala shop near me - Falcon Foods | 
          Dry fruits near me - Falcon Foods | Falcon Foods Palghar to Mumbai delivery
        </p>
        <p>
          Looking for the best spice shop near you? Falcon Foods offers premium quality spices, 
          masalas, dry fruits, rice, and flour in Mumbai, Virar, Vasai, Nalasopara, Palghar, 
          and surrounding areas. We are your trusted local spice store with custom packaging 
          and bulk order options.
        </p>
      </div>

      <section
        className="relative h-96 bg-gradient-to-r from-orange-600 to-amber-600 bg-center bg-cover"
        style={{
          backgroundImage:
            "url('https://img.freepik.com/premium-photo/colorful-different-spices_752237-13041.jpg?w=2000')",
        }}
      >
        {/* Gradient and Dark Overlay */}
        <div className="absolute inset-0 bg-black/40" />

        <div className="relative h-full flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center text-amber-100"
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-4 drop-shadow-lg">
                Premium Spices
              </h1>
              <p className="text-xl md:text-2xl mb-6 drop-shadow">
                Authentic flavors from the heart of India
              </p>
              <p className="text-lg max-w-3xl mx-auto drop-shadow-sm">
                Turmeric, Coriander, Red Chili, Cumin, Pepper, Cloves, Rice, Flour – Available in every size
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Spice Collection
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Handpicked and quality-tested spices for authentic taste. 
              <strong> Falcon Foods - Best spice shop in Mumbai, Virar, Vasai, Nalasopara, Palghar</strong>
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {spices.map((spice, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                className="bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow"
                itemScope
                itemType="https://schema.org/Product"
              >
                <div
                  className="h-64 bg-cover bg-center"
                  style={{ backgroundImage: `url(${spice.image})` }}
                  itemProp="image"
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xl font-bold text-gray-900" itemProp="name">
                      {spice.name}
                    </h3>
                    <div className="flex items-center space-x-1">
                      {[...Array(spice.rating)].map((_, i) => (
                        <Star key={i} size={16} className="fill-orange-400 text-orange-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4" itemProp="description">
                    {spice.description}
                  </p>
                  <div className="mb-4">
                    <span className="text-sm font-semibold text-gray-700">Available Sizes: </span>
                    <span className="text-sm text-gray-600">{spice.sizes}</span>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href={`tel:${phoneNumber}`}
                      className="flex-1 flex items-center justify-center space-x-1 bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-full text-sm font-semibold transition-colors"
                      aria-label={`Call Falcon Foods for ${spice.name}`}
                    >
                      <Phone size={16} />
                      <span>Call</span>
                    </a>
                    <a
                      href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(
                        `Hello! I'm interested in ${spice.name} from Falcon Foods. I came from your website https://www.falconfood.in/ and would like to know more details.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-full text-sm font-semibold transition-all shadow-md hover:shadow-lg"
                      aria-label={`Message on WhatsApp for ${spice.name}`}
                    >
                      <FaWhatsapp size={18} className="text-green-300" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-r from-orange-600 to-amber-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Custom Orders & Bulk Pricing Available
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Need specific packaging or bulk quantities? Contact us for customized solutions. 
              We deliver across Mumbai, Virar, Vasai, Nalasopara, Palghar and surrounding areas.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <a
                href={`tel:${phoneNumber}`}
                className="flex items-center space-x-2 bg-white text-orange-600 hover:bg-gray-100 px-8 py-3 rounded-full font-semibold transition-colors shadow-lg"
                aria-label="Call Falcon Foods for spices and dry fruits"
              >
                <Phone size={20} />
                <span>Call Now</span>
              </a>
              <Link
                to="/contact"
                className="flex items-center space-x-2 bg-transparent border-2 border-white hover:bg-white/10 text-white px-8 py-3 rounded-full font-semibold transition-colors"
              >
                <span>Get Quote</span>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Premium Quality</h3>
              <p className="text-gray-600">Sourced from the best farms across India</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Pure & Natural</h3>
              <p className="text-gray-600">No artificial colors or preservatives</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Custom Packaging</h3>
              <p className="text-gray-600">Available in all sizes as per your needs</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Location Based SEO Section */}
    
    </div>
  );
};

export default SpicesPage;