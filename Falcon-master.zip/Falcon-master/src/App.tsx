import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect, lazy, Suspense } from 'react';
import Lenis from '@studio-freight/lenis';
import Layout from './components/Layout';
import FloatingWhatsApp from './components/FloatingWhatsApp';
import Footer from './components/Footer';

// ✅ Lazy load all heavy pages (for fast initial load)
const HomePage = lazy(() => import('./pages/HomePage'));
const ProductsSection = lazy(() => import('./pages/ProductsSection')); // <-- Fixed here
const SpicesPage = lazy(() => import('./pages/SpicesPage'));
const DryFruitsPage = lazy(() => import('./pages/DryFruitsPage'));
const AboutPage = lazy(() => import('./pages/AboutPage'));
const ContactPage = lazy(() => import('./pages/ContactPage'));

// ✅ ScrollToTop: instantly resets scroll on route change
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [pathname]);
  return null;
};

// ✅ Reusable suspense fallback loader
const Loader = () => (
  <div className="flex items-center justify-center h-screen text-gray-600 text-lg animate-pulse">
    Loading...
  </div>
);

function App() {
  // ✅ Initialize Lenis Smooth Scrolling
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.0,
      easing: (t) => 1 - Math.pow(2, -10 * t),
      smoothWheel: true,
      touchMultiplier: 1.2,
    });

    let frame: number;
    const raf = (time: number) => {
      lenis.raf(time);
      frame = requestAnimationFrame(raf);
    };

    frame = requestAnimationFrame(raf);
    return () => cancelAnimationFrame(frame);
  }, []);

  return (
    <Router>
      <ScrollToTop />

      <div className="flex flex-col min-h-screen">
        {/* ✅ Main Layout */}
        <div className="flex-1">
          <Layout>
            <Suspense fallback={<Loader />}>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/products" element={<ProductsSection />} />
                <Route path="/spices" element={<SpicesPage />} />
                <Route path="/dry-fruits" element={<DryFruitsPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/contact" element={<ContactPage />} />

                {/* ✅ 404 Fallback */}
                <Route
                  path="*"
                  element={
                    <div className="flex items-center justify-center h-screen text-gray-700 text-lg">
                      404 - Page Not Found
                    </div>
                  }
                />
              </Routes>
            </Suspense>
          </Layout>
        </div>

        {/* ✅ Footer fixed at bottom */}
        <Footer />
      </div>

      {/* ✅ Floating WhatsApp Button */}
      <FloatingWhatsApp />
    </Router>
  );
}

export default App;
