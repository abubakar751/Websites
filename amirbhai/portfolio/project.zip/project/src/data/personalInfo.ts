import { Skill, Project, Education, Experience, Certification, SocialLink } from '../types';
import { Github, Mail, Phone } from 'lucide-react';

export const personalInfo = {
  name: 'Abrar Ahmad',
  title: 'Java Developer Specialist',
  tagline: 'Building robust web applications with Java, Spring Boot, and Angular',
  email: 'abrark4961@gmail.com',
  phone: '+91 6390993014',
  location: 'Sakinaka, Mumbai 400072',
  about: `Experienced Java Developer in building robust web apps using Java, Spring Boot, Angular, and MySQL. Proficient in designing scalable back-end services, developing RESTful APIs, and implementing security protocols with Spring Security. Strong hands-on experience in requirement analysis, system design, and end-to-end development of software solutions. Passionate about creating high performance, user-centric applications with a focus on quality, maintainability, and seamless user experiences.`,
  resumePath: '/abrar-ahmed-resume.pdf', // Path will be updated by user
  profileImage: '/images/photo.jpeg', // Path will be updated by user
  socials: [
    {
      platform: 'GitHub',
      url: 'https://github.com/abrartech9202',
      icon: 'Github'
    },
    {
      platform: 'Email',
      url: 'mailto:abrark4961@gmail.com',
      icon: 'Mail'
    },
    {
      platform: 'Phone',
      url: 'tel:+916390993014',
      icon: 'Phone'
    }
  ] as SocialLink[]
};

export const skills: Skill[] = [
  // Backend
  { name: 'Core Java', level: 95, category: 'backend' },
  { name: 'Spring Boot', level: 90, category: 'backend' },
  { name: 'Spring MVC', level: 85, category: 'backend' },
  { name: 'Hibernate', level: 80, category: 'backend' },
  { name: 'J2EE', level: 85, category: 'backend' },
  { name: 'RESTful APIs', level: 90, category: 'backend' },
  { name: 'Microservices', level: 75, category: 'backend' },
  { name: 'Java 8 Features', level: 90, category: 'backend' },
  { name: 'Collections Framework', level: 85, category: 'backend' },
  
  // Frontend
  { name: 'Angular', level: 70, category: 'frontend' },
  { name: 'Angular Material', level: 65, category: 'frontend' },
  { name: 'JavaScript', level: 75, category: 'frontend' },
  { name: 'TypeScript', level: 70, category: 'frontend' },
  { name: 'HTML', level: 80, category: 'frontend' },
  { name: 'CSS', level: 75, category: 'frontend' },
  
  // Database
  { name: 'MySQL', level: 85, category: 'database' },
  { name: 'Oracle', level: 80, category: 'database' },
  { name: 'SQL', level: 90, category: 'database' },
  { name: 'JDBC', level: 85, category: 'database' },
  { name: 'JPA', level: 80, category: 'database' },
  
  // DevOps/Tools
  { name: 'Docker', level: 70, category: 'devops' },
  { name: 'Apache Kafka', level: 65, category: 'devops' },
  { name: 'Git/GitHub', level: 80, category: 'devops' },
  { name: 'GitLab', level: 75, category: 'devops' },
  { name: 'Bitbucket', level: 75, category: 'devops' },
  { name: 'Postman', level: 85, category: 'devops' },
  { name: 'Swagger', level: 80, category: 'devops' },
  
  // Other
  { name: 'JSON', level: 90, category: 'other' },
  { name: 'XML', level: 85, category: 'other' },
  { name: 'GraphQL', level: 65, category: 'other' },
  { name: 'STS IDE', level: 80, category: 'other' },
  { name: 'IntelliJ IDEA', level: 85, category: 'other' }
];

export const projects: Project[] = [
  {
    id: 1,
    title: 'Audit Management Software',
    description: 'Developed the Risk Management Module and led a team of 34 developers. Utilized Liqui-base, Spring Boot, and Angular for module integration and feature delivery.',
    skills: ['Spring Boot', 'Angular', 'Liqui-base', 'Team Leadership'],
    images: [
      'https://images.pexels.com/photos/6804581/pexels-photo-6804581.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/8636590/pexels-photo-8636590.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    achievements: ['90% improvement in risk identification accuracy']
  },
  {
    id: 2,
    title: 'e-DigiSalesSystem',
    description: 'The e-DigiSalesSystem is a digital sales management platform designed to streamline and automate the sales process of an organization. It aims to provide a comprehensive solution for managing product catalogs, customer orders, sales representatives, and real-time analytics. The system focuses on enhancing the efficiency of sales operations, improving customer experiences, and ensuring seamless order tracking and management.',
    skills: ['Java 1.8', 'Spring Boot', 'RESTful API', 'MySQL', 'Angular'],
    images: [
      'https://images.pexels.com/photos/6801874/pexels-photo-6801874.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/7688334/pexels-photo-7688334.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ]
  },
  {
    id: 3,
    title: 'Exam Portal',
    description: 'The Exam Portal allows students to take quizzes online while offering comprehensive admin capabilities. Admins can create, update, and manage quizzes, including setting questions and configuring quiz parameters. The system ensures smooth quiz functionality for students, with features like time limits and result tracking. It also provides detailed reporting for both students and administrators.',
    skills: ['Java', 'Spring Boot', 'JPA', 'Angular', 'MySQL'],
    images: [
      'https://images.pexels.com/photos/4145153/pexels-photo-4145153.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/4219104/pexels-photo-4219104.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ]
  }
];

export const education: Education[] = [
  {
    degree: 'Bachelor of Science in Information Technology (B.Sc IT)',
    institution: 'Mumbai University',
    year: '2021 - 2024',
    description: 'Focused on computer science fundamentals, programming paradigms, and modern application development.'
  }
];

export const experience: Experience[] = [
  {
    title: 'Java Developer',
    company: 'IT Solutions Ltd.',
    period: '2022 - Present',
    description: [
      'Developed and maintained enterprise Java applications using Spring Boot and Microservices',
      'Implemented RESTful APIs for communication between services',
      'Optimized database queries and improved application performance',
      'Collaborated in Agile teams to deliver high-quality software solutions'
    ]
  },
  {
    title: 'Software Developer Intern',
    company: 'Tech Innovators',
    period: '2021 - 2022',
    description: [
      'Assisted in developing Java-based web applications',
      'Gained hands-on experience with Spring Framework and Hibernate',
      'Participated in code reviews and testing phases'
    ]
  }
];

export const certifications: Certification[] = [
  {
    name: 'Oracle Cloud Infrastructure Certified Foundations Associate',
    issuer: 'Oracle University',
    year: '2023',
    description: 'Validated knowledge of Oracle Cloud Infrastructure services and functionality'
  }
];

export const achievements = [
  'Led a team of 34 developers for the Risk Management Module project',
  'Achieved 90% improvement in risk identification accuracy in Audit Management Software',
  'Successfully implemented microservices architecture reducing system load by 40%',
  'Optimized database queries resulting in 30% faster application response time'
];